/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_range.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aacikyil <42kocaeli.com.tr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/09/14 23:10:24 by aacikyil          #+#    #+#             */
/*   Updated: 2022/09/14 23:28:07 by aacikyil         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_ultimate_range(int **range, int min, int max)
{
	int	i;
	int	*tab;

	if (min >= max)
	{
		*range = NULL;
		return (0);
	}
	tab = (int *)malloc(sizeof(int) * (max - min));
	if (tab == NULL)
		return (-1);
	else
	{
		i = 0;
		while (i < max - min)
		{
			tab[i] = min + i;
			i++;
		}
		*range = tab;
		return (i);
	}
}
/*
#include <stdio.h>
int		main(void)
{
	int		*range;
	int		i;

	i = 0;
	printf("return edilen değer :%d\n", ft_ultimate_range(&range, 10, 20));
	while (i < 10)
	{
		printf("Range'in içi");
	printf("%d\n", range[i]);
		i++;
	}
	return (0);
}*/
